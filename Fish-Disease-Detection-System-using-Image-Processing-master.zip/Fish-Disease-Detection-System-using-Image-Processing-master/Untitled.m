clc;
clear all;
close all;
[fname path]=uigetfile('*.*','Enter an image');
fname=strcat(path,fname);
subplot(2,2,1);
im=imread(fname);
im=imresize(im,[256,256]);
imshow(im);
im1=rgb2gray(im);
figure();
subplot(2,2,1);
imhist(im1);
%%thresholding 
imA= im1>150;
imA=~imA;
r=regionprops(imA);
for(i=1:length(r)
    if((r(i).Area<1000) && (r(i).Area>50))
        rr=r(1).BoundingBox;
    end
end
imshow(im);
hold on;
rectangle('position',rr,'Edgecolor','g');