clc;
clear all;
close all;
[fname path]=uigetfile('*.*','Enter an image');
fname=strcat(path,fname);
subplot(2,2,1);
im=imread(fname);
imshow(im)
title('Enter your input image')
%% separate each color channel
imR=im;
imR(:,:,2:3)=0;
subplot(2,2,2);
imshow(imR);
title('red part');
imG=im;
imG(:,:,1:2:3)=0;
subplot(2,2,3);
imshow(imG);
title('Green part')
imB=im;
imB(:,:,1:2)=0;
subplot(2,2,4);
imshow(imB);
title('Blue part')
%% rather than other channel 0, let's select the channel
imR1=im(:,:,1);
imG1=im(:,:,2);
imB1=im(:,:,3);
figure;
subplot(2,2,1);
imshow(imR1);
title('red part');
subplot(2,2,2);
imshow(imG1);
title('Green part');
subplot(2,2,3);
imshow(imB1);
title('Blue part');
imGray=rgb2gray(im);
subplot(2,2,4);
imshow(imGray)
title('RGB to GRAY');
%%Using Formula for Gray Conversation
imGray2=uint8(0.299*double(imR1)+0.587*double(imG1)+0.114*double(imB1));
figure;
imshow(imGray2);
title('Gray using Formula');




