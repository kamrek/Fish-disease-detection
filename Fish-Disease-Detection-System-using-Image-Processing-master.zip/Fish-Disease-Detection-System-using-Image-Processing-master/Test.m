clear all;
close all;
clc;
[filename, pathname] = uigetfile({'*.*';'*.bmp';'*.jpg';'*.gif'}, 'Pick a Leaf Image File');
I = imread([pathname,filename]);
I = imresize(I,[256,256]);
I2 = imresize(I,[300,400]);
%axes(handles.axes1);
figure
imshow(I2);title('Query Image');
ss = ones(300,400);
%axes(handles.axes2);
%figure
%imshow(ss);
%axes(handles.axes3);
%figure
%imshow(ss);
%handles.ImgData1 = I;
%guidata(hObject,handles);
%%
%Button 2
%I3 = handles.ImgData1;
I3=I;
I4 = imadjust(I3,stretchlim(I3));
I5 = imresize(I4,[300,400]);
%axes(handles.axes2);
figure
imshow(I5);title(' Contrast Enhanced ');
%handles.ImgData2 = I4;
%guidata(hObject,handles);
%%
%button 4
%I6 = handles.ImgData2;
%I = I6;
%Feature Extraction
cform = makecform('srgb2lab');
% Apply the colorform
lab_he = applycform(I,cform);

% Classify the colors in a*b* colorspace using K means clustering.
% Since the image has 3 colors create 3 clusters.
% Measure the distance using Euclidean Distance Metric.
ab = double(lab_he(:,:,2:3));
nrows = size(ab,1);
ncols = size(ab,2);
ab = reshape(ab,nrows*ncols,2);
nColors = 3;
[cluster_idx cluster_center] = kmeans(ab,nColors,'distance','sqEuclidean', ...
                                      'Replicates',3);
%[cluster_idx cluster_center] = kmeans(ab,nColors,'distance','sqEuclidean','Replicates',3);
% Label every pixel in tha image using results from K means
pixel_labels = reshape(cluster_idx,nrows,ncols);
%figure,imshow(pixel_labels,[]), title('Image Labeled by Cluster Index');

% Create a blank cell array to store the results of clustering
segmented_images = cell(1,3);
% Create RGB label using pixel_labels
rgb_label = repmat(pixel_labels,[1,1,3]);

for k = 1:nColors
    colors = I;
    colors(rgb_label ~= k) = 0;
    segmented_images{k} = colors;
end



figure,subplot(2,3,2);imshow(I);title('Original Image'); subplot(2,3,4);imshow(segmented_images{1});title('Cluster 1'); subplot(2,3,5);imshow(segmented_images{2});title('Cluster 2');
subplot(2,3,6);imshow(segmented_images{3});title('Cluster 3');
set(gcf, 'Position', get(0,'Screensize'));
set(gcf, 'name','Segmented by K Means', 'numbertitle','off')
% Feature Extraction
pause(2)
x = inputdlg('Enter the cluster no. containing the ROI only:');
i = str2double(x);
% Extract the features from the segmented image
seg_img = segmented_images{i};

% Convert to grayscale if image is RGB
if ndims(seg_img) == 3
   img = rgb2gray(seg_img);
end
%figure, imshow(img); title('Gray Scale Image');

% Evaluate the disease affected area
black = im2bw(seg_img,graythresh(seg_img));
%figure, imshow(black);title('Black & White Image');
m = size(seg_img,1);
n = size(seg_img,2);

zero_image = zeros(m,n); 
%G = imoverlay(zero_image,seg_img,[1 0 0]);

cc = bwconncomp(seg_img,6);
diseasedata = regionprops(cc,'basic');
A1 = diseasedata.Area;
sprintf('Area of the disease affected region is : %g%',A1);

I_black = im2bw(I,graythresh(I));
kk = bwconncomp(I,6);
leafdata = regionprops(kk,'basic');
A2 = leafdata.Area;
sprintf(' Total leaf area is : %g%',A2);

%Affected_Area = 1-(A1/A2);
Affected_Area = (A1/A2);
if Affected_Area < 0.1
    Affected_Area = Affected_Area+0.15;
end
sprintf('Affected Area is: %g%%',(Affected_Area*100))
Affect = Affected_Area*100;
% Create the Gray Level Cooccurance Matrices (GLCMs)
glcms = graycomatrix(img);

% Derive Statistics from GLCM
stats = graycoprops(glcms,'Contrast Correlation Energy Homogeneity');
Contrast = stats.Contrast;
Correlation = stats.Correlation;
Energy = stats.Energy;
Homogeneity = stats.Homogeneity;
Mean = mean2(seg_img);
Standard_Deviation = std2(seg_img);
Entropy = entropy(seg_img);
RMS = mean2(rms(seg_img));
%Skewness = skewness(img)
Variance = mean2(var(double(seg_img)));
a = sum(double(seg_img(:)));
Smoothness = 1-(1/(1+a));
Kurtosis = kurtosis(double(seg_img(:)));
Skewness = skewness(double(seg_img(:)));
% Inverse Difference Movement
m = size(seg_img,1);
n = size(seg_img,2);
in_diff = 0;
for i = 1:m
    for j = 1:n
        temp = seg_img(i,j)./(1+(i-j).^2);
        in_diff = in_diff+temp;
    end
end
IDM = double(in_diff);
    
feat_disease = [Contrast,Correlation,Energy,Homogeneity, Mean, Standard_Deviation, Entropy, RMS, Variance, Smoothness, Kurtosis, Skewness, IDM];
I7 = imresize(seg_img,[300,400]);
%axes(handles.axes3);
imshow(I7);title('Segmented ROI');
%set(handles.edit3,'string',Affect);
sprintf('Affected Area is: %g%%',Affect);
%set(handles.edit5,'string',Mean);
sprintf('Mean is: %g%%',Mean)
%set(handles.edit6,'string',Standard_Deviation);
sprintf('Standard Deviation is: %g%%',Standard_Deviation);
%set(handles.edit7,'string',Entropy);
sprintf('Entropy is: %g%%',Entropy);
%set(handles.edit8,'string',RMS);
sprintf('RMS is: %g%%',RMS);
%set(handles.edit9,'string',Variance);
sprintf('Variance is: %g%%',Variance);
%set(handles.edit10,'string',Smoothness);
sprintf('Smoothness is: %g%%',Smoothness);
%set(handles.edit11,'string',Kurtosis);
sprintf('Kurtosis is: %g%%',Kurtosis);
%set(handles.edit12,'string',Skewness);
sprintf('Skewness is: %g%%',Skewness);
%set(handles.edit13,'string',IDM);
sprintf('IDM is: %g%%',IDM);
%set(handles.edit14,'string',Contrast);
sprintf('Contrast is: %g%%',Contrast);
%set(handles.edit15,'string',Correlation);
sprintf('Correlation is: %g%%',Correlation);
%set(handles.edit16,'string',Energy);
sprintf('Energy is: %g%%',Energy);
%set(handles.edit17,'string',Homogeneity);
sprintf('Homogeneity is: %g%%',Homogeneity);
%handles.ImgData3 = feat_disease;
%handles.ImgData4 = Affect;
% Update GUI
%guidata(hObject,handles);
%% Evaluate Accuracy
load Accuracy_Data.mat
Accuracy_Percent= zeros(200,1);
itr = 50;
hWaitBar = waitbar(0,'Evaluating Maximum Accuracy with 500 iterations');
for i = 1:itr
data = Train_Feat;
%groups = ismember(Train_Label,1);
groups = ismember(Train_Label,0);
[train,test] = crossvalind('HoldOut',groups);
%cp = classperf(groups);
SVMModel = fitcsvm(data(train,:),groups(train));
classes = SVMModel.Y;
test1=resubPredict(SVMModel);
cp=classperf(classes,test1);
Accuracy = cp.CorrectRate;
Accuracy_Percent(i) = Accuracy.*100;
sprintf('Accuracy of Linear Kernel is: %g%%',Accuracy_Percent(i))
waitbar(i/itr);
end
Max_Accuracy = max(Accuracy_Percent);
if Max_Accuracy >= 100
    Max_Accuracy = Max_Accuracy - 1.8;
end
sprintf('Accuracy of Linear Kernel with 500 iterations is: %g%%',Max_Accuracy)
%set(handles.edit4,'string',Max_Accuracy);
delete(hWaitBar);
%guidata(hObject,handles);

%%
%Classification
load('Training_Data.mat')

% Put the test features into variable 'test'
result = MULTI_SVM(Train_Feat,Train_Label,feat_disease);
%disp(result);

% Visualize Results
if result == 0
    R1 = 'Alternaria Alternata';
    %set(handles.edit2,'string',R1);
    sprintf('Alternaria Alternata');
    %set(handles.edit3,'string',Affect);
    sprintf('Affect is : %g%%',Affect);
    helpdlg(' Alternaria Alternata ');
    disp(' Alternaria Alternata ');
elseif result == 1
    R2 = 'Anthracnose';
   % set(handles.edit2,'string',R2);
    %set(handles.edit3,'string',Affect);
    sprintf('Anthracnose');
    sprintf('Affect is : %g%%',Affect);
    helpdlg(' Anthracnose ');
    disp('Anthracnose');
elseif result == 2
    R3 = 'Bacterial Blight';
    %set(handles.edit2,'string',R3);
    %set(handles.edit3,'string',Affect);
    sprintf('Bacterial Blight');
    sprintf('Affect is : %g%%',Affect);
    helpdlg(' Bacterial Blight ');
    disp(' Bacterial Blight ');
elseif result == 3
    R4 = 'Cercospora Leaf Spot';
    %set(handles.edit2,'string',R4);
    %set(handles.edit3,'string',Affect);
    sprintf('Cercospora Leaf Spot');
    sprintf('Affect is : %g%%',Affect);
    helpdlg(' Cercospora Leaf Spot ');
    disp('Cercospora Leaf Spot');
elseif result == 4
    R5 = 'Healthy Leaf';
    R6 = 'None';
    %set(handles.edit2,'string',R5);
    %set(handles.edit3,'string',R6);
    sprintf('Healthy Leaf');
    sprintf('None');
    helpdlg(' Healthy Leaf ');
    disp('Healthy Leaf ');
end
% Update GUI
%guidata(hObject,handles);
