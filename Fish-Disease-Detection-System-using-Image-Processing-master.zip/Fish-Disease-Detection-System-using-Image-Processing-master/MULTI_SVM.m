function [result]=MULTI_SVM(trainfeatures,trainLable,testfeatures)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MULTI_SVM for clssify multi group multi testfeatures               %
% devloped in Bangladesh(Rangamati Science and Technology University)%
% Copyright (C)2020 by Utpol Kanti Das                               %
%All rights reserved.                                                %
%programed in mathlab 2018                                           %
%gmail:utpoldasrmstu@gmail.com                                       %
%phone number:+8801859222633                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% clc
% clear all
% close all
% load TrainingDataBase
% Train_Feat=TrainingFeatures;
% Train_Label= grp2idx(TrainingSpecies);

 Train_Feat=trainfeatures;
 Train_Label=trainLable;

%testfeatures=[0.0157169120000000,0.908416230000000,0.812917696000000,0.992141544000000,0.0944213870000000,0.292414070000000,0.451058131000000,0.239009641000000,0.0754860070000000,0.999838423000000,8.69508730500000,2.77400203800000,114.808991300000]
row=size(Train_Feat,1)
class=unique(Train_Label);

%data=[0,0,0,0,0,0,0,0,0,0,0,0,0]
%%
    score=1;
    MaxAccuracy=0;
for i=1:3
   % count=0;
    k=1;    
    traindata=[];
    classLabel=[];
   for j=1:row
       if(Train_Label(j)== score || Train_Label(j)== class(i+1))
           %count=count+1
           traindata(k,:)=Train_Feat(j,:);
           classLabel(:,k)=Train_Label(:,j);
           k=k+1;
       end
   end
  %c(i)=count
     SVM=fitcsvm(traindata,classLabel,'KernelFunction','rbf');
     classes = SVM.Y;
     test=resubPredict(SVM);
     cp=classperf(classes,test);

%      groups = ismember(classLabel,1);
%      [train,test] = crossvalind('HoldOut',groups);
%      SVMModel = fitcsvm(traindata(train,:),groups(train));
%      classes = SVMModel.Y;
%      test1=resubPredict(SVMModel);
%      cp=classperf(classes,test1);
%      
     Accuracy = cp.CorrectRate;
    if Accuracy>MaxAccuracy
        MaxAccuracy=Accuracy
    end
    
%   SVM=fitcsvm(traindata,classLabel,'KernelFunction','rbf');
    score=predict(SVM,testfeatures)
end
 sprintf('The maximum Accuracy is %g%%',MaxAccuracy*100)
%  a=MaxAccuracy*100;
%  result=score;
%  if result==1
%      msgbox(['Benign Tumor Detected' newline 'The Accuracy of Multi-SVM is = ',num2str(a),'%'])
%  elseif result==2
%      msgbox(['Malignant Tumor Detected\' newline 'The Accuracy of Multi-SVM is = ',num2str(a),'%'])
%  elseif result==3
%      msgbox(['Leukemia Detected' newline 'The Accuracy of Multi-SVM is = ',num2str(a),'%'])
%  elseif result==4
%      msgbox(['Lung Cancer Detected' newline 'The Accuracy of Multi-SVM is = ',num2str(a),'%'])
% end
%  msgbox(['The Accuracy of SVM is = ',num2str(a),'%'])
  result=score
end