clc;
clear all;
close all;
[fname path]=uigetfile('*.*','Enter an image');
fname=strcat(path,fname);
subplot(2,2,1);
im=imread(fname);
im=imresize(im,[256,256]);
imshow(im);
subplot(2,2,2);
imhist(im);


